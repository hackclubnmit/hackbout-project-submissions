rootProject.name = "osmosis-server"
